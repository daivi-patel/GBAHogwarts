/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 hogwarts hogwarts.jpg 
 * Time-stamp: Wednesday 04/01/2020, 01:59:08
 * 
 * Image Information
 * -----------------
 * hogwarts.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HOGWARTS_H
#define HOGWARTS_H

extern const unsigned short hogwarts[38400];
#define HOGWARTS_SIZE 76800
#define HOGWARTS_LENGTH 38400
#define HOGWARTS_WIDTH 240
#define HOGWARTS_HEIGHT 160

#endif

