/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 broom broom.jpg 
 * Time-stamp: Thursday 04/02/2020, 00:07:53
 * 
 * Image Information
 * -----------------
 * broom.jpg 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BROOM_H
#define BROOM_H

extern const unsigned short broom[225];
#define BROOM_SIZE 450
#define BROOM_LENGTH 225
#define BROOM_WIDTH 15
#define BROOM_HEIGHT 15

#endif

