/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 bludger bludger.jpg 
 * Time-stamp: Thursday 04/02/2020, 00:01:58
 * 
 * Image Information
 * -----------------
 * bludger.jpg 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLUDGER_H
#define BLUDGER_H

extern const unsigned short bludger[225];
#define BLUDGER_SIZE 450
#define BLUDGER_LENGTH 225
#define BLUDGER_WIDTH 15
#define BLUDGER_HEIGHT 15

#endif

