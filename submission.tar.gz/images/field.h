/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 field field.jpg 
 * Time-stamp: Wednesday 04/01/2020, 03:13:09
 * 
 * Image Information
 * -----------------
 * field.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FIELD_H
#define FIELD_H

extern const unsigned short field[38400];
#define FIELD_SIZE 76800
#define FIELD_LENGTH 38400
#define FIELD_WIDTH 240
#define FIELD_HEIGHT 160

#endif

