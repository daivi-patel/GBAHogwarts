/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 snitch snitch.png 
 * Time-stamp: Thursday 04/02/2020, 04:30:57
 * 
 * Image Information
 * -----------------
 * snitch.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SNITCH_H
#define SNITCH_H

extern const unsigned short snitch[225];
#define SNITCH_SIZE 450
#define SNITCH_LENGTH 225
#define SNITCH_WIDTH 15
#define SNITCH_HEIGHT 15

#endif

