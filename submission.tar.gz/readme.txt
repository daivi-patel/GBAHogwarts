This is a quidditch game. On the title page, hit Start (Enter) to begin.
On the next page, the arrow keys control the broom image. You can move it up,
down, left, or right. If your broom hits the bludger (brown ball), you lose.
If your broom his the snitch (golden ball), you win! You can hit select 
(backspace) at any time in the program to return to the start screen.